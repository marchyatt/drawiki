'use strict'

export default {
  name: 'admin-settings',
  data() {
    return {}
  },
  methods: {
    flushcache() {
      window.alert('Coming soon!')
    },
    resetaccounts() {
      window.alert('Coming soon!')
    },
    flushsessions() {
      window.alert('Coming soon!')
    }
  }
}
