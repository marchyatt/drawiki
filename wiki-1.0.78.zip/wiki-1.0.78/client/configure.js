'use strict'

require('./scss/configure.scss')
require('./js/configure.js')
